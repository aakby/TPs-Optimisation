#!/Applications/Julia-1.4.app/Contents/Resources/julia/bin/julia

function helloworld()
    println("Hello, World!") # Bye bye, MATLAB!
end

helloworld()

